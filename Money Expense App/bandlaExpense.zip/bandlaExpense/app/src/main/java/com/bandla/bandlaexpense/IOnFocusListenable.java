package com.bandla.bandlaexpense;

/**
 * Created by lavan on 4/15/2018.
 */

public interface IOnFocusListenable {
    public void onWindowFocusChanged(boolean hasFocus);
}