package com.bandla.bandlaexpense;

/**
 * Created by lavan on 4/15/2018.
 */

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;


public class AccountsFragment extends Fragment {
    Point p;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Accounts");

        return inflater.inflate(R.layout.activity_accounts, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Toolbar toolbar1 = (Toolbar) getActivity().findViewById(R.id.accounts_toolbar);
        toolbar1.setTitle("CAD Accounts (Default)");
        toolbar1.inflateMenu(R.menu.accounts_menu);

        final AppCompatImageButton btn_show = (AppCompatImageButton) getView().findViewById(R.id.show_popup);
        btn_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                int[] location = new int[2];

                btn_show.getLocationOnScreen(location);
                p = new Point();
                p.x = location[0];
                p.y = location[1];

                if (p != null)
                    showPopup(getActivity(), p);
            }
        });

        final AppCompatImageButton btn_mid_show = (AppCompatImageButton) getView().findViewById(R.id.show_popup_mid);
        btn_mid_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                int[] location = new int[2];
                // Get the x, y location and store it in the location[] array
                // location[0] = x, location[1] = y.
                btn_show.getLocationOnScreen(location);
                p = new Point();
                p.x = location[0];
                p.y = location[1]+200;

                //Open popup window
                if (p != null)
                    showPopup(getActivity(), p);
            }
        });

    }

    private void showPopup(final Activity context, Point p) {
        int popupWidth = 1100;
        int popupHeight = 1000;

        // Inflate the popup_layout.xml
        LinearLayout viewGroup = (LinearLayout) context.findViewById(R.id.popup);

        LayoutInflater layoutInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = layoutInflater.inflate(R.layout.popup_layout, viewGroup);

        // Creating the PopupWindow
        final PopupWindow popup = new PopupWindow(viewGroup);

        popup.setContentView(layout);
        popup.setWidth(popupWidth);
        popup.setHeight(popupHeight);
        popup.setFocusable(true);

        int OFFSET_X = -40;
        int OFFSET_Y = 140;

        // Clear the default translucent background
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        popup.showAtLocation(layout, Gravity.NO_GRAVITY, p.x + OFFSET_X, p.y + OFFSET_Y);


    }

}