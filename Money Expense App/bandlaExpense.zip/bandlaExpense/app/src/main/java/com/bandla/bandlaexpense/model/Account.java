package com.bandla.bandlaexpense.model;

/**
 * Created by lavan on 4/15/2018.
 */

public class Account {

    private int id;
    private String name;
    private double startBalance;
    private String currency;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public double getStartBalance() {
        return startBalance;
    }
    public void setStartBalance(double balance) {
        this.startBalance = balance;
    }


}
