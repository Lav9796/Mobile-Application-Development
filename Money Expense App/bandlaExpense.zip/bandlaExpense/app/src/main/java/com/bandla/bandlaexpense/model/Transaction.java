package com.bandla.bandlaexpense.model;

/**
 * Created by lavan on 4/15/2018.
 */


public class Transaction {

    private int id;
    private String name;
    private double transAmount;
    private int transType;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getTransAmount() {
        return transAmount;
    }
    public void setTransAmount(double currency) {
        this.transAmount = transAmount;
    }
    public int getTransType() {
        return transType;
    }
    public void setTransType(double currency) {
        this.transType = transType;
    }

}
