package com.bandla.bandlaexpense;

/**
 * Created by lavan on 4/15/2018.
 */

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

public class TransactionsFragment extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
            Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setHasOptionsMenu(true);
        return inflater.inflate(R.layout.fragment_transactions, container, false);
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.trans_settings, menu);
    }


}