package com.bandla.bandlaexpense;

/**
 * Created by lavan on 4/15/2018.
 */

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;


public class OFragment extends Fragment{
    Point p;
    private boolean secondButtonClick = false;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Toolbar toolbar1 = getActivity().findViewById(R.id.toolbar);
        toolbar1.setTitle("Overview");
        setHasOptionsMenu(true);

        return inflater.inflate(R.layout.fragment_o, container, false);
    }

    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.fragment_1_toolbar);
        toolbar.setTitle("My Accounts");
        toolbar.inflateMenu(R.menu.overview_menu);

        Toolbar toolbar1 = (Toolbar) view.findViewById(R.id.fragment_2_toolbar);
        toolbar1.setTitle("Income Vs Expense");
        toolbar1.inflateMenu(R.menu.income_menu);

        final AppCompatImageButton btn_show = (AppCompatImageButton) getView().findViewById(R.id.show_popup);
        btn_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                int[] location = new int[2];
                // Get the x, y location and store it in the location[] array
                // location[0] = x, location[1] = y.
                btn_show.getLocationOnScreen(location);
                p = new Point();
                p.x = location[0];
                p.y = location[1];
                //Open popup window
                if (p != null)
                    secondButtonClick = false;
                showPopup(getActivity(), p);
            }
        });

        final AppCompatImageButton btn_mid_show = (AppCompatImageButton) getView().findViewById(R.id.show_popup_mid);
        btn_mid_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                int[] location = new int[2];
                // Get the x, y location and store it in the location[] array
                // location[0] = x, location[1] = y.
                btn_show.getLocationOnScreen(location);
                p = new Point();
                p.x = location[0];
                p.y = location[1];

                //Open popup window
                if (p != null)
                    secondButtonClick = true;
                showPopup(getActivity(), p);
            }
        });

        CardView cardView = (CardView) getView().findViewById(R.id.myaccounts);
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                FragmentManager manager = getFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                // determine which Fragment to create
                Fragment myFragment = new com.bandla.bandlaexpense.AccountsFragment();
                transaction.replace(R.id.frameTrans, myFragment);
                transaction.addToBackStack("myFragment");
                //menu.setTitle("Accounts");
                transaction.commit();
            }

        });

        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                FragmentManager manager = getFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                // determine which Fragment to create
                Fragment myFragment = new com.bandla.bandlaexpense.AccountsFragment();
                transaction.replace(R.id.frameTrans, myFragment);
                transaction.addToBackStack("myFragment");
                transaction.commit();
            }
        });

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.settings, menu);
    }

    // The method that displays the popup.
    private void showPopup(final Activity context, Point p) {
        int popupWidth = 1100;
        int popupHeight = 1000;

        // Inflate the popup_layout.xml
        LinearLayout viewGroup = (LinearLayout) context.findViewById(R.id.popup);

        LayoutInflater layoutInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = layoutInflater.inflate(R.layout.popup_layout, viewGroup);

        // Creating the PopupWindow
        final PopupWindow popup = new PopupWindow(viewGroup);

        if(secondButtonClick) {
            layout.setBackgroundResource(R.drawable.popupbgmid);
            //layout.setBackground(getResources().getDrawable(R.drawable.popupbgmid));
            secondButtonClick = false;
        }

        popup.setContentView(layout);
        popup.setWidth(popupWidth);
        popup.setHeight(popupHeight);
        popup.setFocusable(true);

        int OFFSET_X = -40;
        int OFFSET_Y = 140;

        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        // Displaying the popup at the specified location, + offsets.

        popup.showAtLocation(layout, Gravity.NO_GRAVITY, p.x + OFFSET_X, p.y + OFFSET_Y);

    }

}